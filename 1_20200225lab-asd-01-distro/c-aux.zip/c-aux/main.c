#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <time.h>

// prototipi 
void launcher(int*, int);
int *randArray(int);
void printArray(int*, int);


//
void bubbleSort(int*, int);



int * randArray(int n) {
    srand(time(NULL));
    int *v = malloc(n*sizeof(int));
    for(int i = 0; i < n; i++) v[i] = rand();
    return v;
}

void launcher(int *a, int n) {
    printArray(a, n);
    printf("Lancio il Bubble Sort... ");
    // prendi il tempo qui con clock
    bubbleSort(a, n);
    // prendi di nuovo il tempo qui con clock())    
    printf("fatto. Tempo: ?? msec.\n"); // sostituisci a ?? %g e stampa il tempo in msec
    printArray(a, n);
}

void printArray(int *a, int n) {
    printf("L'array ha %d elementi\n", n);
    for(int i = 0; i < n; i++) printf("array[%d] = %d\n", i, a[i]);
    printf("Fine array.\n");
}


int main(int argc, char *argv[]) {
    // test
    // for (int i = 0; i < argc; i++) printf("argomento n. %d è %s\n", i, argv[i]);
    
    int a[] = {4, 6, 1, 9, 2, 0, 7, 5, 11, -1, 0, 13, 12, 21};
    launcher(a, 14);
    return 0;
}
