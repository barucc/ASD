#include "mat_sparsa_lista.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct elem {
	int i, j, x;
	struct elem *next;
} elem;

struct matrice_sparsa {
	int m, n;
	elem* head;
};

matrice_sparsa* matrice_sparsa_new(int m, int n) {
	// TODO: Implement here
	matrice_sparsa *out = (matrice_sparsa*) malloc(sizeof(matrice_sparsa));
	out->m = m;
	out->n = n;
	return out;
}

void matrice_sparsa_delete(matrice_sparsa* mat, int i, int j) {
	// TODO: Implement here
	if(!mat->head)	return;
	elem *e = mat->head;
	elem *c = NULL;
	elem *tmp = NULL;
	while(e->next){
			
		if(e->i == i && e->j == j){
			tmp = e;
			c->next = e->next;
			free(tmp);
			return;
		}
		c = e;
		e = e->next;
	}
	if(e->i == i && e->j == j){
		tmp = e;
		c->next = e->next;
		free(tmp);	
		return;
	}
	
}

int get_num_row(matrice_sparsa* mat) {
	// TODO: Implement here
	return mat->m;
}

int get_num_col(matrice_sparsa* mat) {
	// TODO: Implement here
	return mat->n;
}

void mat_set(matrice_sparsa* mat, int i, int j, int x) {
	// TODO: Implement here
	if(get_num_row(mat)<=i || get_num_col(mat)<=j){
		printf("Exceeds bounds\n");
		return;
	}
	if(x==0){
		matrice_sparsa_delete(mat, i, j);
		return;
	}
	if(!mat->head){
		mat->head = (elem*) malloc(sizeof(elem));
		elem *e = mat->head;
		e->i = i; e->j = j; e-> x = x;
	}
	else{
		elem *e = mat->head;
		while(e->next){
			if(e->i == i && e->j == j){
				e->x = x;
				return;
			}
			e = e->next;
		}
		if(e->i == i && e->j == j){
			e->x = x;	
			//printf("last");
			return;
		}
		e->next = (elem*) malloc(sizeof(elem));
		e = e->next;
		e->i = i; e->j = j; e->x = x;
		
		
	}
	
}

int mat_get(matrice_sparsa* mat, int i, int j) {
	// TODO: Implement here
	int x = 0;
	elem *e = mat->head;
	if(e==NULL)	return x;
	else{
		if(e->i == i && e->j == j)	return e->x;
	}
	
	while(e->next){
		if(e->i == i && e->j == j)	return e->x;
		e = e->next;
	}
	if(e->i == i && e->j == j)	x = e->x;
	return x;
}

void mat_print(matrice_sparsa* mat) {
	// TODO: Implement here
	if(!mat->head)	return;
	elem *e = mat->head;
	int r = get_num_row(mat); 
	int c = get_num_col(mat);
	for(int m=0; m<r; m++){
		for(int n=0; n<c; n++){
			printf("%d ", mat_get(mat, m,n)); 
		}
		printf("\n");
	}
	printf("\n");
	while(e->next){
		printf("%d ", e->x);
		e=e->next;
	}
	printf("%d \n", e->x);
	
}
